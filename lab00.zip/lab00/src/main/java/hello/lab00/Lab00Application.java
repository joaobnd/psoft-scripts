package hello.lab00;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab00Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab00Application.class, args);
	}

}
